//
//  CustomStepView.swift
//  ShoppingCar
//
//  Created by macc on 16/10/28.
//  Copyright © 2016年 ZhengGuiJie. All rights reserved.
//

import UIKit

/**
 控件类型
 
 - custome: 默认
 - circle:  外层带圆圈
 */
enum StepType {
    case custom
    case circle
}

/**
 控件点击类型
 
 - add:    加
 - reduce: 减
 */
enum ClickType {
    case add
    case reduce
}

/**
 *  控件的基本设置
 */
struct Appearance {
    /// ➕/➖的颜色
    var actionColor: UIColor
    /// circle类型时，外围圆圈颜色
    var strokeColor: UIColor
    var fillColor: UIColor
    /// 字体颜色
    var textColor: UIColor
    /// 字体
    var textFont: UIFont
}


class ZGJStepView: UIView {

    typealias TypeClouse = ClickType -> Void
    var stepType: StepType
    private lazy var label = UILabel()
    /// 最小值  默认0
    var minimumValue: Double = 0 {
        didSet {
            self.value = minimumValue
            if minimumValue % 1.0 == 0.0 {
              label.text = "\(Int(minimumValue))"
            } else {
              label.text = "\(minimumValue)"
            }
        }
    }
    /// 最大值默认 100
    var maximumValue: Double = 100
    /// 每一次点击增减值 默认1
    var stepValue: Double = 1
    /// 当前值---默认0
    var value: Double = 0 {
        didSet {
            if stepValue % 1.0 == 0.0 && minimumValue % 1.0 == 0.0 {
                label.text = "\(Int(value))"
            } else {
                label.text = "\(value)"
            }
        }
    }
    /// 设置控件外观
    var appearance: Appearance! {
        didSet {
            self.draw()
        }
    }
    /// 点击代理
    weak var delegate: StepDelegate?
    private var action: TypeClouse?
    /**
     初始化方法
     
     - parameter frame: 控件frame--若想circle类型时，成圆形，最好宽高比为10:3
     - parameter type:  控件类型
     - action: 点击闭包，可选代理或者闭包，二选1
     
     - returns: 此控件
     */
    init(frame: CGRect, type: StepType, action: TypeClouse?) {
        self.stepType = type
        self.action = action
        super.init(frame: frame)
        defaultAppearance()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension ZGJStepView {
    private func reset() {
        for sub in subviews {
            sub.removeFromSuperview()
        }
        if let layers = layer.sublayers {
            for lay in layers {
                lay.removeFromSuperlayer()
            }
        }
    }
    
    private func draw() {
        reset()
        let centerY = frame.size.height * 0.5
        let width = frame.size.width
        let linePath = UIBezierPath()
        defer {
            linePath.closePath()
        }
        //(- : label : +) = (3:4:3)
        // 画减号
        //(空白:-:空白) = (3:4:3)
        //线条宽度/高度
        let lineHeight = frame.size.height / 3
        // 减号起始点
        let startX1 = width * 0.3 * 0.3
        linePath.moveToPoint(CGPoint(x: startX1, y: centerY))
        linePath.addLineToPoint(CGPoint(x: startX1 + lineHeight, y: centerY))
        // 画加号
        //(空白:+:空白) = (3:4:3)
        //横线
        // 加号起始点
        let startX2 = width - width * 0.3 * 0.3 - lineHeight
        linePath.moveToPoint(CGPoint(x: startX2, y: centerY))
        linePath.addLineToPoint(CGPoint(x: startX2 + lineHeight, y: centerY))
        //竖线
        linePath.moveToPoint(CGPoint(x: startX2 + lineHeight * 0.5, y: centerY - lineHeight * 0.5))
        linePath.addLineToPoint(CGPoint(x: startX2 + lineHeight * 0.5, y: centerY + lineHeight * 0.5))
        
        let lineLayer = CAShapeLayer()
        lineLayer.path = linePath.CGPath
        lineLayer.strokeColor = appearance.actionColor.CGColor
        lineLayer.lineWidth = 1
        self.layer.addSublayer(lineLayer)
        
        let (leftFrame, remainFrame) = bounds.divide(bounds.size.width * 0.3, fromEdge: .MinXEdge)
        let (middleFrame, rightFrame) = remainFrame.divide(remainFrame.size.width * 4 / 7, fromEdge: .MinXEdge)
 
        label.frame = middleFrame
        addSubview(label)
        label.textAlignment = .Center
        label.textColor = appearance.textColor
        label.font = appearance.textFont
        label.adjustsFontSizeToFitWidth = true
        
        //添加action
        let reduceC = UIControl(frame: leftFrame)
        reduceC.addTarget(self, action: #selector(reduce), forControlEvents: .TouchUpInside)
        addSubview(reduceC)
        
        let addC = UIControl(frame: rightFrame)
        addC.addTarget(self, action: #selector(add), forControlEvents: .TouchUpInside)
        addSubview(addC)
        
        switch stepType {
        case .circle:
            let scale: CGFloat = 0.7
            let reduceFrame = CGRect(x: leftFrame.size.width * 0.5 * (1 - scale), y: centerY - leftFrame.size.height * scale * 0.5, width: leftFrame.size.width * scale, height: leftFrame.size.height * scale)
            let reducePath = UIBezierPath(ovalInRect: reduceFrame)
            let reduceLayer = CAShapeLayer()
            reduceLayer.path = reducePath.CGPath
            reduceLayer.fillColor = appearance.fillColor.CGColor
            reduceLayer.strokeColor = appearance.strokeColor.CGColor
            reduceLayer.lineWidth = 1
            layer.addSublayer(reduceLayer)
            
            let addFrame = CGRect(x: startX2 + lineHeight * 0.5 - rightFrame.size.width * scale * 0.5, y: centerY - rightFrame.size.height * scale * 0.5, width: rightFrame.size.width * scale, height: rightFrame.size.height * scale)
            let addPath = UIBezierPath(ovalInRect: addFrame)
            let addLayer = CAShapeLayer()
            addLayer.path = addPath.CGPath
            addLayer.fillColor = appearance.fillColor.CGColor
            addLayer.strokeColor = appearance.strokeColor.CGColor
            addLayer.lineWidth = 1
            layer.addSublayer(addLayer)
        case .custom:
            return
        }
    }
    
    func reduce() {
        if let delegate = delegate {
            delegate.didClick(.reduce)
        }
        if let action = action {
            action(.reduce)
        }
    }
    
    func add() {
        if let delegate = delegate {
          delegate.didClick(.add)
        }
        if let action = action {
            action(.add)
        }
    }
    
    private func defaultAppearance() {
        minimumValue = 0
        appearance = Appearance(
            actionColor: UIColor.blackColor(),
            strokeColor: UIColor.redColor(),
            fillColor: UIColor.clearColor(),
            textColor: UIColor.blackColor(),
            textFont: UIFont.systemFontOfSize(15))
    }
}

/// 控件点击代理
protocol StepDelegate: class {
    func didClick(type: ClickType)
}
