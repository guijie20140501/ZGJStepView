//
//  SteepViewController.swift
//  ShoppingCar
//
//  Created by macc on 16/10/28.
//  Copyright © 2016年 ZhengGuiJie. All rights reserved.
//

import UIKit

class SteepViewController: UIViewController {

    private lazy var label = UILabel()
    private var stepV: ZGJStepView!
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "step"
        setUpUI()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

extension SteepViewController {
    private func setUpUI() {
    stepV = ZGJStepView(frame: CGRect(x: 50, y: 400, width: 300, height: 90), type: .custom, action: nil)
        
        stepV.backgroundColor = UIColor.lightGrayColor()
        stepV.minimumValue = 2
        stepV.maximumValue = 10
        stepV.stepValue = 1
        stepV.delegate = self
        stepV.appearance = Appearance(
            actionColor: UIColor.redColor(),
            strokeColor: UIColor.redColor(),
            fillColor: UIColor.clearColor(),
            textColor: UIColor.blackColor(),
            textFont: UIFont.systemFontOfSize(15))
        view.addSubview(stepV)
    }
}

extension SteepViewController: StepDelegate {
    func didClick(type: ClickType) {
        switch type {
        case .reduce:
            if stepV.value > stepV.minimumValue {
                stepV.value -= self.stepV.stepValue
            }
        case .add:
            if stepV.value < stepV.maximumValue {
                stepV.value += self.stepV.stepValue
            }
        }
    }
}
